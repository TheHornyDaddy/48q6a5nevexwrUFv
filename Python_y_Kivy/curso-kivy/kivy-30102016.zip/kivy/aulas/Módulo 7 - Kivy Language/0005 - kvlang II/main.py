#coding: utf-8

#author: Cláudio Rogério Carvalho Filho

#####################
#### eXcript.com ####
#####################

import kivy
kivy.require("1.9.1")
from kivy.app import App

class Estudo2App(App):
    pass

janela = Estudo2App()
janela.run()
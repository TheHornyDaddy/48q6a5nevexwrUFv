#coding: utf-8

#author: Cláudio Rogério Carvalho Filho

#####################
#### eXcript.com ####
#####################

import kivy
kivy.require("1.9.1")
from kivy.app import App

class Estudo1App(App):
    pass

janela = Estudo1App()
janela.run()